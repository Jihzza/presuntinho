# Equivalenza Mid-Term — Deliverables (V3)

**Course:** BCOBM311 — Creative Business Cases · EU Business School · Summer 2026
**Author:** Fatma · **Professor:** Prof. Cristina Elson
**Deadline:** Monday June 29, 2:00 PM · Moodle / Turnitin

---

## What's in this ZIP (V3)

| File | What it is | Open with |
|------|------------|-----------|
| `presuntinho.html` | Interactive study hub — **9 pages**, 5 quizzes (4 academic + 1 Portuguese) with real answer-checking, **15 unlockable badges**, **8 easter eggs** (with progressive escalation up to 5000 clicks), **burger menu on mobile**, **Secrets page** with locked/unlocked hint cards, **Portuguese mini-course** (5 vowels + 50 words + 3 dialogues + 5 verbs + 5-question quiz). State persists via `localStorage`. Mobile-first responsive. | Any modern browser. Double-click the file. |
| `Equivalenza_Mid_Term_Fatma.pdf` | **17-page** final academic report. Professional navy/gold cover, executive summary, SWOT (Equivalenza + Divain), buyer persona (Marta 27, Madrid), Marketing Problem (SCQA), TOWS matrix with **4 distinct pastels**, per-quadrant strategy detail (Why + Implementation), Risk Analysis (5 risks ranked + mitigation), KPIs table (5 metrics with baseline/target/method/frequency), Pilot-phase weekly milestones, **15 Harvard-style references** (italicized journal titles), Appendix A (case data), Appendix B (buyer persona visual — standard 8-section template), Appendix C (competitor pricing across 5 brands × 5 SKUs), Appendix D (sensory marketing mini-summary). | Any PDF reader. |
| `audio_intro_en.mp3` | **~80-second spoken walkthrough in English** (en-US-AriaNeural voice). Walks you through every deliverable, every page of the site, all 8 easter eggs, and the recommended study flow. | Any audio player. |
| `audio_intro_pt-PT.mp3` | 22-second Portuguese version (pt-PT-RaquelNeural voice). Bonus. | Any audio player. |
| `README.md` | This file. | — |

---

## How to open the study hub (`presuntinho.html`)

1. Double-click `presuntinho.html`. It opens in your default browser.
2. No install, no server, no internet required — everything is inlined.
3. Mobile-first, but looks good on desktop / TV / tablet.
4. **On mobile (≤720px wide):** tap the **☰** button at the top right to open the navigation menu. Tap **✕** or anywhere outside to close.

---

## The 9 pages

1. **Home** — XP, badges, module progress, get-started buttons, motivational quote.
2. **The Case** — Equivalenza's situation, SWOT analyses (Equivalenza + Divain).
3. **Course** — Class concepts (SWOT, persona, SCQA, TOWS) in quick-reference form.
4. **Walkthrough** — Step-by-step guide to writing each section of the mid-term.
5. **🔐 Secrets** — Easter-egg hint map. 8 cards, all hints visible, rewards unlock progressively.
6. **Quizzes** — 4 academic quizzes (SWOT categorization, TOWS matching, case facts, persona) with real answer-checking.
7. **Writing** — Sentence starters, structure templates, common pitfalls.
8. **🇵🇹 PT** — Portuguese mini-course (5 vowels, 50 words in 7 categories, 3 dialogues, 5-verb cheat sheet, 5-question quiz → badge "🇵🇹 Lusófono").
9. **Downloads** — This ZIP, the PDF, the audio files.

---

## Easter eggs (try them all!)

| Easter egg | How to trigger | Reward |
|------------|----------------|--------|
| ❤️ Heart click | Click the heart button at bottom-right | Escalates forever: +20 XP at click 1, +50 at 10, +100 at 100, +500 at 1000, rainbow mode activates at 200, heart transforms at 1000. Badges `b10`, `b13`, `b12`. |
| 🐷 Logo triple-click | Click the 🐷 logo 3× within 3 seconds | +30 XP + confetti |
| 🐷 Logo 6–8× | Click the 🐷 logo 6, 7, or 8 times within 3 seconds (tolerance!) | Secret Room opens + +100 XP + badge `b14`. One-time only. |
| 🎮 Konami code | Press ↑ ↑ ↓ ↓ ← → ← → B A anywhere | +100 XP + badge `b8` + confetti |
| ⌨️ "perfume" | Type `perfume` anywhere | +50 XP + badge `b7` + confetti |
| ⌨️ "behi" | Type `behi` anywhere (means "beautiful" in Tunisian Arabic) | +50 XP + badge `b9` + confetti |
| 🧴 Mascot pro-tips | Click the 🧴 mascot (appears after first navigation away from home) | Random writing tip + +5 XP per click |
| 🐷 Footer 5× | Click the footer text 5 times | Hint toast + badge `b15` |

**Secrets page:** open the "🔐 Secrets" page in the nav to see all 8 easter eggs as cards. Cards are locked (greyed, reward blurred) until you discover them. As you discover each one, it unlocks with confetti and shows the full reward text plus the timestamp.

**State persists across reloads** (localStorage). Open DevTools → Application → Local Storage → `presuntinho` to inspect.

---

## The PDF (`Equivalenza_Mid_Term_Fatma.pdf`) — 17 pages

1. **Cover** — Navy/gold brand band, EU Business School logo block, assignment metadata.
2. **Table of Contents** — With page numbers and dot leaders.
3. **Executive Summary** — 200-word SCQA of the whole assignment + recommendation.
4–5. **SWOT — Equivalenza** (Strengths, Weaknesses, Opportunities, Threats).
6. **SWOT — Divain** (key competitor).
7. **Buyer Persona** — Marta (Demographics, Psychographics, Behavioural, Day-in-the-Life, Frustrations, Channel Preferences, Key Insight, Strategic Importance).
8. **Marketing Problem** — SCQA framework.
9. **TOWS Matrix** — 4 distinct pastel quadrants (green SO, blue WO, orange ST, pink WT).
10. **Per-Quadrant Strategy Detail** — Why + Implementation for SO, ST, WO, WT.
11. **Strategic Alternative** — "Les Secrets Everywhere" (SO recommendation) + Pilot weekly milestones + Personal Reflection.
12. **Risk Analysis** — 5 risks ranked by likelihood × impact, with mitigation.
13. **KPIs** — 5 metrics (NPS, avg ticket, Les Secrets share, footfall, online conversion) with baseline / target / method / frequency.
14. **References** — 15 Harvard-style entries, journal titles italicized.
15. **Appendix A** — Key case data table.
16. **Appendix B** — Buyer-persona visual (standard 8-section template: Photo, Name/Role, Quote, Bio Narrative, Goals, Frustrations, Day-in-Life, Channel Preferences).
17. **Appendix C** — Competitor pricing across 5 brands × 5 SKUs.
18. **Appendix D** — Sensory marketing mini-summary (5 levers + why it matters for Equivalenza).

(Actually closer to 17 pages depending on content flow — the actual page numbers print at the bottom of every page after the cover.)

---

## The audio (`audio_intro_en.mp3`)

~80-second spoken walkthrough in English (en-US-AriaNeural). It explains every deliverable, every page of the site, all 8 easter eggs, and the recommended study flow. Play it once at the start of your study session, then play the Portuguese version (audio_intro_pt-PT.mp3) as a side-quest.

---

## Suggested study flow

1. Play `audio_intro_en.mp3` (or the pt-PT version).
2. Open `presuntinho.html` on your phone. Navigate with the burger menu.
3. Start at "The Case" → read both SWOT analyses.
4. Go to "Buyer Persona" → internalize Marta.
5. Go to "Course" → review SCQA + TOWS.
6. Go to "Quizzes" → test yourself (real answer-checking).
7. Go to "Walkthrough" → draft your paper section by section.
8. Go to "🔐 Secrets" → find all 8 easter eggs.
9. Visit "🇵🇹 PT" → take the Portuguese mini-quiz for badge `b11`.
10. Open `Equivalenza_Mid_Term_Fatma.pdf` → that's your final deliverable. Read it.
11. Rewrite Sections 3, 4, and 5 in your own voice before submitting.

Boa sorte, Fatma! 🐷
